//
//  GFSViewController.h
//  Tweetings
//
//  Created by James Dempsey on 10/12/12.
//  Copyright (c) 2012 Good Fun Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GFSViewController : UIViewController

- (IBAction)showTweetSheet:(id)sender;

@end
