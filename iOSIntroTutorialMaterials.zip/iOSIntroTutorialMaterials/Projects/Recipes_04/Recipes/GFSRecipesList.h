//
//  GFSRecipesList.h
//  Recipes
//
//  Created by James Dempsey on 10/20/12.
//  Copyright (c) 2012 Good Fun Software. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GFSRecipesDataSource.h"

@interface GFSRecipesList : NSObject <GFSRecipesDataSource>

@end
